import { Routes, Route } from 'react-router-dom';
import { Login } from './pages/Login.jsx';
import { DashboardMaestro } from './pages/DashboardMaestro.jsx';
import { PerfilMaestro } from './pages/PerfilMaestro.jsx';
import { ProtectedRoute } from './components/ProtectedRoute.jsx';
import { AdminLayout } from './components/AdminLayout.jsx';
import { DashboardAdmin } from './pages/DashboardAdmin.jsx';
import { AdminReservas } from './pages/AdminReservas.jsx';
import { AdminClases } from './pages/AdminClases.jsx';
import { AdminMarketing } from './pages/AdminMarketing.jsx';
import { AdminMaestros } from './pages/AdminMaestro.jsx';
import { AdminAcademia } from './pages/AdminAcademia.jsx';
import { CrearPassword } from './pages/CrearPassword.jsx';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/crear-password" element={<CrearPassword />} />
      
      <Route 
        path="/admin" 
        element={
          <ProtectedRoute allowedRole="ADMIN">
            <AdminLayout />
          </ProtectedRoute>
        } 
      >
        <Route index element={<DashboardAdmin />} />
        <Route path="reservas" element={<AdminReservas />} />
        <Route path="clases" element={<AdminClases />} />
        <Route path="maestros" element={<AdminMaestros />} />
        <Route path="academia" element={<AdminAcademia />} />
        <Route path="marketing" element={<AdminMarketing />} />
      </Route>
      
      <Route 
        path="/maestro" 
        element={
          <ProtectedRoute allowedRole="MAESTRO">
            <DashboardMaestro />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/maestro/perfil" 
        element={
          <ProtectedRoute allowedRole="MAESTRO">
            <PerfilMaestro />
          </ProtectedRoute>
        } 
      />
    </Routes>
  );
}

export default App;