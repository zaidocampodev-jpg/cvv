import { useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { FaBars, FaTimes } from 'react-icons/fa'; // Asegúrate de tener instalada react-icons

export const AdminLayout = () => {
  const { logout } = useAuth();
  const location = useLocation();
  
  // Estado para controlar si el menú móvil está abierto o cerrado
  const [menuAbierto, setMenuAbierto] = useState(false);

  const navItems = [
    { path: '/admin', label: 'Resumen' },
    { path: '/admin/reservas', label: 'Reservas y Pagos' },
    { path: '/admin/clases', label: 'Gestión de Clases' },
    { path: '/admin/maestros', label: 'Gestión de Maestros' },
    { path: '/admin/academia', label: 'Página Academia' },
    { path: '/admin/marketing', label: 'Marketing' },
  ];

  const toggleMenu = () => setMenuAbierto(!menuAbierto);
  const cerrarMenu = () => setMenuAbierto(false);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row font-sans">
      
      {/* --- HEADER MÓVIL (Solo visible en celulares) --- */}
      <div className="md:hidden flex items-center justify-between bg-white border-b border-gray-200 p-4 sticky top-0 z-40 shadow-sm">
        <div>
          <h2 className="text-xl font-serif font-bold text-slate-900 italic">Estilo Latino</h2>
          <p className="text-[10px] text-gray-400 tracking-widest uppercase mt-1 font-bold">Admin Panel</p>
        </div>
        <button 
          onClick={toggleMenu} 
          className="text-slate-900 text-2xl focus:outline-none p-2"
        >
          {menuAbierto ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      {/* --- OVERLAY OSCURO (Solo visible en celulares cuando el menú está abierto) --- */}
      {menuAbierto && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 md:hidden backdrop-blur-sm transition-opacity"
          onClick={cerrarMenu}
        ></div>
      )}

      {/* --- MENÚ LATERAL --- */}
      <aside 
        className={`fixed md:relative top-0 left-0 h-full w-64 bg-white border-r border-gray-200 flex flex-col z-50 transform transition-transform duration-300 ease-in-out md:translate-x-0 ${
          menuAbierto ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:shadow-sm'
        }`}
      >
        <div className="p-8 border-b border-gray-100 hidden md:block">
          <h2 className="text-2xl font-serif font-bold text-slate-900 italic">Estilo Latino</h2>
          <p className="text-xs text-gray-400 tracking-widest uppercase mt-2 font-bold">Admin Panel</p>
        </div>
        
        <nav className="flex-1 p-6 space-y-3 overflow-y-auto">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={cerrarMenu} // Cierra el menú al seleccionar una opción en celular
              className={`block px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                location.pathname === item.path
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'text-gray-500 hover:bg-gray-100 hover:text-slate-900'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="p-6 border-t border-gray-100 bg-white">
          <button
            onClick={logout}
            className="w-full px-4 py-3 text-xs font-bold text-slate-900 border-2 border-slate-200 rounded-lg hover:border-slate-900 hover:bg-slate-900 hover:text-white transition-all uppercase tracking-widest"
          >
            Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* --- CONTENIDO PRINCIPAL --- */}
      {/* Añadí padding (p-4 md:p-8) para que el contenido respire en todas las pantallas */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 w-full">
        <Outlet />
      </main>

    </div>
  );
};