import { createContext, useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const token = localStorage.getItem('estiloLatinoToken');
    const rol = localStorage.getItem('estiloLatinoRol');
    const nombre = localStorage.getItem('estiloLatinoNombre');
    return token ? { token, rol, nombre } : null;
  });
  
  const navigate = useNavigate();

  const login = async (correo, password) => {
    try {
      const { data } = await api.post('/auth/login', { correo, password });
      
      setUser({ token: data.token, rol: data.rol, nombre: data.nombre });
      
      localStorage.setItem('estiloLatinoToken', data.token);
      localStorage.setItem('estiloLatinoRol', data.rol);
      localStorage.setItem('estiloLatinoNombre', data.nombre);

      if (data.rol === 'ADMIN') {
        navigate('/admin'); 
      } else if (data.rol === 'MAESTRO') {
        navigate('/maestro'); 
      }
      
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || "Error al conectar con el servidor." 
      };
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('estiloLatinoToken');
    localStorage.removeItem('estiloLatinoRol');
    localStorage.removeItem('estiloLatinoNombre');
    navigate('/');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};