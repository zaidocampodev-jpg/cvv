import { useState, useEffect, useRef } from 'react';
import Swal from 'sweetalert2';
import api from '../services/api';
import { 
  FaTrash, FaPlus, FaSave, FaImage, FaSpinner, 
  FaUpload, FaLink, FaHistory, FaThLarge 
} from 'react-icons/fa';

export const AdminAcademia = () => {
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const portadaRef = useRef(null);
  
  const [datos, setDatos] = useState({
    imagenPortada: '',
    historia: '',
    secciones: []
  });

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    try {
      const { data } = await api.get('/public/academia');
      setDatos({
        imagenPortada: data.imagenPortada || '',
        historia: data.historia || '',
        secciones: data.secciones || []
      });
    } catch (error) {
      console.error(error);
      Swal.fire('Error', 'No se pudo cargar la información actual.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubirPortada = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('archivo', file);
    
    Swal.fire({ title: 'Subiendo portada...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
      const { data } = await api.post('/admin/academia/portada', formData, { headers: { 'Content-Type': 'multipart/form-data' }});
      setDatos({ ...datos, imagenPortada: data.url });
      Swal.close();
    } catch (error) {
      Swal.fire('Error', 'No se pudo subir la portada.', 'error');
    }
  };

  const handleSubirImagenGaleria = (seccionIndex) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const formData = new FormData();
      formData.append('archivo', file);
      
      Swal.fire({ title: 'Subiendo imagen...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
      try {
        const { data } = await api.post('/admin/academia/galeria', formData, { headers: { 'Content-Type': 'multipart/form-data' }});
        const nuevasSecciones = [...datos.secciones];
        if (!nuevasSecciones[seccionIndex].galeria) nuevasSecciones[seccionIndex].galeria = [];
        nuevasSecciones[seccionIndex].galeria.push({ id: Date.now(), tipo: 'archivo', url: data.url });
        setDatos({ ...datos, secciones: nuevasSecciones });
        Swal.close();
      } catch (error) {
        Swal.fire('Error', 'No se pudo subir la imagen.', 'error');
      }
    };
    input.click();
  };

  const handleAgregarEnlaceMultimedia = (seccionIndex) => {
    Swal.fire({
      title: 'Añadir Video o Enlace',
      html: `
        <select id="swal-tipo" class="swal2-input" style="font-size: 14px; width: 80%;">
          <option value="youtube">Video de YouTube</option>
          <option value="enlace">Reel o Enlace Externo</option>
        </select>
        <input id="swal-url" class="swal2-input" placeholder="Pega el enlace aquí..." style="font-size: 14px; width: 80%;">
      `,
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Añadir',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#0f172a',
      preConfirm: () => {
        const tipo = document.getElementById('swal-tipo').value;
        const url = document.getElementById('swal-url').value;
        if (!url) Swal.showValidationMessage('Necesitas ingresar un enlace');
        return { tipo, url };
      }
    }).then((result) => {
      if (result.isConfirmed) {
        const nuevasSecciones = [...datos.secciones];
        if (!nuevasSecciones[seccionIndex].galeria) nuevasSecciones[seccionIndex].galeria = [];
        nuevasSecciones[seccionIndex].galeria.push({ id: Date.now(), tipo: result.value.tipo, url: result.value.url });
        setDatos({ ...datos, secciones: nuevasSecciones });
      }
    });
  };

  const handleAgregarSeccion = () => {
    const nuevaSeccion = { idTemp: Date.now(), titulo: 'Nueva Sección', descripcion: '', galeria: [] };
    setDatos({ ...datos, secciones: [...datos.secciones, nuevaSeccion] });
  };

  const handleEliminarSeccion = (index) => {
    const nuevasSecciones = [...datos.secciones];
    nuevasSecciones.splice(index, 1);
    setDatos({ ...datos, secciones: nuevasSecciones });
  };

  const handleSeccionChange = (index, campo, valor) => {
    const nuevasSecciones = [...datos.secciones];
    nuevasSecciones[index][campo] = valor;
    setDatos({ ...datos, secciones: nuevasSecciones });
  };

  const handleEliminarMultimedia = (seccionIndex, multiIndex) => {
    const nuevasSecciones = [...datos.secciones];
    nuevasSecciones[seccionIndex].galeria.splice(multiIndex, 1);
    setDatos({ ...datos, secciones: nuevasSecciones });
  };

  const handleGuardarTodo = async () => {
    setIsSubmitting(true);
    try {
      await api.put('/admin/academia', datos);
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Página actualizada', showConfirmButton: false, timer: 3000 });
      cargarDatos();
    } catch (error) {
      Swal.fire('Error', 'Hubo un problema al guardar los cambios', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex justify-center items-center bg-white"><FaSpinner className="animate-spin text-slate-900" size={40} /></div>;
  }

  return (
    <div className="p-6 md:p-12 font-sans min-h-screen bg-gray-50/50 pb-32 relative">
      
      {/* BARRA SUPERIOR CORREGIDA */}
      <div className="sticky top-0 z-30 bg-gray-50/90 backdrop-blur-md border-b border-gray-200 py-4 mb-10 -mt-6 md:-mt-12 transition-all">
        <div className="max-w-6xl mx-auto flex justify-between items-center px-4 md:px-0">
          <div>
            <h1 className="text-xl md:text-2xl font-serif font-bold text-slate-900 tracking-tight leading-none">Academia</h1>
            <p className="hidden md:block text-slate-500 mt-1 text-[9px] tracking-[0.2em] uppercase font-bold">Gestión de Contenido</p>
          </div>
          
          <button 
            onClick={handleGuardarTodo} 
            disabled={isSubmitting} 
            className="px-4 py-2 md:px-6 md:py-3 bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-black rounded-full shadow-md flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
          >
            {isSubmitting ? <FaSpinner className="animate-spin" /> : <FaSave />} 
            <span>{isSubmitting ? '...' : 'Guardar Cambios'}</span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* SECCIÓN 1: PORTADA E HISTORIA */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 bg-white p-2 rounded-[2rem] border border-gray-100 shadow-xl shadow-slate-200/50 overflow-hidden group">
            <div className="relative h-[300px] md:h-[350px] w-full rounded-[1.6rem] overflow-hidden bg-slate-100 border border-gray-100">
              {datos.imagenPortada ? (
                <img src={datos.imagenPortada} alt="Portada" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-400">
                  <FaImage size={48} className="mb-4 opacity-20" />
                  <span className="text-[10px] font-bold uppercase tracking-tighter">Sin Imagen</span>
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <input type="file" accept="image/*" className="hidden" ref={portadaRef} onChange={handleSubirPortada} />
                <button onClick={() => portadaRef.current.click()} className="px-6 py-3 bg-white text-slate-900 text-[10px] font-bold uppercase tracking-widest rounded-full shadow-2xl hover:bg-slate-50 transition-colors flex items-center gap-2">
                  <FaUpload /> Subir Nueva
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 bg-white p-6 md:p-10 rounded-[2rem] border border-gray-100 shadow-xl shadow-slate-200/50 flex flex-col">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                <FaHistory size={12} />
              </div>
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-[0.15em]">Nuestra Historia</h2>
            </div>
            <textarea 
              rows="8" 
              value={datos.historia} 
              onChange={(e) => setDatos({...datos, historia: e.target.value})} 
              className="flex-1 w-full p-5 rounded-2xl bg-slate-50/50 border border-slate-100 text-slate-600 text-sm leading-relaxed focus:bg-white focus:outline-none resize-none transition-all"
            ></textarea>
          </div>
        </div>

        {/* SECCIÓN 2: SECCIONES DINÁMICAS */}
        <div className="space-y-8">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-white shadow-md">
                <FaThLarge size={12} />
              </div>
              <h2 className="text-lg font-serif font-bold text-slate-900">Bloques y Galerías</h2>
            </div>
            
            {/* BOTÓN NUEVA SECCIÓN CORREGIDO */}
            <button 
              onClick={handleAgregarSeccion} 
              className="px-5 py-2.5 bg-white text-slate-900 text-[10px] font-bold uppercase tracking-widest border border-slate-200 rounded-full hover:bg-slate-900 hover:text-white transition-all flex items-center justify-center gap-2 whitespace-nowrap shadow-sm"
            >
              <FaPlus size={10} /> Nueva Sección
            </button>
          </div>

          <div className="grid grid-cols-1 gap-10">
            {datos.secciones.length === 0 ? (
              <div className="text-center py-16 bg-white border-2 border-dashed border-slate-200 rounded-[2.5rem]">
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">Aún no has agregado secciones adicionales</p>
              </div>
            ) : (
              datos.secciones.map((seccion, index) => (
                <div key={seccion.id || seccion.idTemp} className="group relative bg-white rounded-[2.5rem] border border-gray-100 shadow-xl shadow-slate-200/40 overflow-hidden">
                  
                  <button onClick={() => handleEliminarSeccion(index)} className="absolute top-6 right-6 w-8 h-8 bg-red-50 text-red-400 hover:bg-red-500 hover:text-white rounded-full flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 z-10">
                    <FaTrash size={10} />
                  </button>

                  <div className="p-6 md:p-10">
                    <div className="max-w-xl mb-8">
                      <input 
                        type="text" 
                        value={seccion.titulo} 
                        onChange={(e) => handleSeccionChange(index, 'titulo', e.target.value)} 
                        placeholder="Título de la sección" 
                        className="w-full bg-transparent border-b border-gray-100 focus:border-slate-300 text-xl font-serif font-bold text-slate-900 focus:outline-none pb-2 transition-all" 
                      />
                      <textarea 
                        rows="2" 
                        value={seccion.descripcion} 
                        onChange={(e) => handleSeccionChange(index, 'descripcion', e.target.value)} 
                        placeholder="Descripción corta..." 
                        className="w-full mt-3 bg-transparent text-slate-500 text-xs focus:outline-none resize-none"
                      ></textarea>
                    </div>

                    <div className="bg-slate-50/50 rounded-[2rem] p-5 md:p-8 border border-slate-100">
                      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Contenido ({seccion.galeria?.length || 0})</span>
                        <div className="flex gap-2">
                          <button onClick={() => handleSubirImagenGaleria(index)} className="px-4 py-2 bg-white text-slate-800 text-[9px] font-bold uppercase tracking-widest border border-slate-200 rounded-full hover:shadow-sm flex items-center gap-2">
                            <FaUpload className="text-slate-400" /> Foto
                          </button>
                          <button onClick={() => handleAgregarEnlaceMultimedia(index)} className="px-4 py-2 bg-white text-slate-800 text-[9px] font-bold uppercase tracking-widest border border-slate-200 rounded-full hover:shadow-sm flex items-center gap-2">
                            <FaLink className="text-slate-400" /> Video
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
                        {seccion.galeria && seccion.galeria.map((item, multiIndex) => (
                          <div key={item.id || multiIndex} className="relative aspect-[4/5] bg-white rounded-2xl overflow-hidden group/item border border-slate-200 shadow-sm transition-transform hover:-translate-y-1">
                            {item.tipo === 'archivo' ? (
                              <img src={item.url} alt="Galeria" className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-slate-900 text-white">
                                <span className="text-2xl mb-2">{item.tipo === 'youtube' ? '▶️' : '🔗'}</span>
                                <span className="text-[7px] font-bold uppercase tracking-[0.2em] opacity-60 truncate w-full">{item.tipo}</span>
                              </div>
                            )}
                            <div className="absolute inset-0 bg-red-500/90 opacity-0 group-hover/item:opacity-100 transition-opacity flex items-center justify-center">
                              <button onClick={() => handleEliminarMultimedia(index, multiIndex)} className="w-10 h-10 bg-white text-red-500 rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                                <FaTrash size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};