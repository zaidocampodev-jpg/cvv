import { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import api from '../services/api';

export const AdminClases = () => {
  const [clases, setClases] = useState([]);
  const [listaMaestros, setListaMaestros] = useState([]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [claseEditandoId, setClaseEditandoId] = useState(null);

  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    maestroId: '',
    cupoTotal: '',
    limiteSueltas: '',
    precioMensual: '',
    precioSuelta: ''
  });

  const [horariosTemp, setHorariosTemp] = useState([]);
  const [nuevoHorario, setNuevoHorario] = useState({ dia: 'Lunes', hora: '' });

  const fetchDatosInit = async () => {
    try {
      const resClases = await api.get('/public/clases');
      const clasesMapeadas = resClases.data.map(c => {
        const diasTexto = c.horarios && c.horarios.length > 0 
          ? c.horarios.map(h => h.dia).join(', ') 
          : 'Sin horarios';

        return {
          id: c.id,
          nombre: c.nombre,
          horario: diasTexto, 
          horariosDetalle: c.horarios || [],
          maestro: c.maestro?.nombre || 'Sin asignar',
          maestroId: c.maestroId?.toString() || '',
          descripcion: c.descripcion,
          cupoTotal: c.cupoTotal,
          limiteSueltas: c.limiteSueltas,
          cupoOcupado: c.reservas?.length || 0, 
          precios: { suelta: c.precioSuelta, mensual: c.precioMensual },
          estado: 'ACTIVA' // Nota: Si tu backend devuelve el estado, puedes usar c.estado en lugar de hardcodearlo
        };
      });
      setClases(clasesMapeadas);
    } catch (error) {
      console.error(error);
    }

    try {
      const resMaestros = await api.get('/auth/admin/maestros');
      setListaMaestros(resMaestros.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchDatosInit();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAgregarHorario = () => {
    if (nuevoHorario.hora.trim() === '') return;
    setHorariosTemp([...horariosTemp, { ...nuevoHorario, idTemp: Date.now() }]);
    setNuevoHorario({ dia: 'Lunes', hora: '' });
  };

  const handleEliminarHorario = (idTemp) => {
    setHorariosTemp(horariosTemp.filter(h => h.idTemp !== idTemp));
  };

  const handleNuevaClase = () => {
    setClaseEditandoId(null);
    setFormData({
      nombre: '', descripcion: '', maestroId: '', cupoTotal: '',
      limiteSueltas: '', precioMensual: '', precioSuelta: ''
    });
    setHorariosTemp([]);
    setNuevoHorario({ dia: 'Lunes', hora: '' });
    setIsModalOpen(true);
  };

  const handleEditar = (clase) => {
    setClaseEditandoId(clase.id);
    setFormData({
      nombre: clase.nombre,
      descripcion: clase.descripcion || '',
      maestroId: clase.maestroId || '',
      cupoTotal: clase.cupoTotal || '',
      limiteSueltas: clase.limiteSueltas || '',
      precioMensual: clase.precios.mensual || '',
      precioSuelta: clase.precios.suelta || ''
    });
    setHorariosTemp(clase.horariosDetalle ? clase.horariosDetalle.map(h => ({ ...h, idTemp: h.id || Date.now() })) : []);
    setIsModalOpen(true);
  };

  // --- NUEVA FUNCIÓN: ARCHIVAR CLASE ---
  const handleArchivar = async (id) => {
    const confirmacion = await Swal.fire({
      title: '¿Archivar clase?',
      text: "La clase dejará de ser visible y no recibirá nuevas reservas, pero mantendrá su historial intacto.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444', // Rojo para acción destructiva/archivar
      cancelButtonColor: '#0f172a',
      confirmButtonText: 'Sí, archivar',
      cancelButtonText: 'Cancelar'
    });

    if (confirmacion.isConfirmed) {
      try {
        // Asegúrate de que esta ruta coincide con la de tu backend. 
        // Si usaste /admin/clases para PUT/POST, es probable que DELETE también lo sea.
        await api.delete(`/admin/clases/${id}`); 
        
        Swal.fire({ 
          title: '¡Archivada!', 
          text: 'La clase fue archivada correctamente.', 
          icon: 'success', 
          confirmButtonColor: '#0f172a' 
        });
        
        fetchDatosInit(); // Recarga la lista para que desaparezca la clase archivada
      } catch (error) {
        Swal.fire({ 
          title: 'Error', 
          text: error.response?.data?.error || 'No se pudo archivar la clase.', 
          icon: 'error', 
          confirmButtonColor: '#0f172a' 
        });
      }
    }
  };

  const handleGuardarClase = async (e) => {
    e.preventDefault();

    if (horariosTemp.length === 0) {
      Swal.fire({ title: 'Atención', text: 'Debes agregar al menos un horario.', icon: 'warning', confirmButtonColor: '#0f172a' });
      return;
    }
    
    if (!formData.maestroId) {
      Swal.fire({ title: 'Falta Maestro', text: 'Debes seleccionar un maestro.', icon: 'error', confirmButtonColor: '#0f172a' });
      return;
    }

    const payload = {
        nombre: formData.nombre,
        descripcion: formData.descripcion,
        cupoTotal: parseInt(formData.cupoTotal),
        limiteSueltas: parseInt(formData.limiteSueltas),
        precioSuelta: parseFloat(formData.precioSuelta),
        precioPaquete: parseFloat(formData.precioMensual), 
        precioMensual: parseFloat(formData.precioMensual),
        maestroId: parseInt(formData.maestroId),
        horarios: horariosTemp.map(h => ({ dia: h.dia, hora: h.hora }))
    };

    try {
        if (claseEditandoId) {
            await api.put(`/admin/clases/${claseEditandoId}`, payload);
            Swal.fire({ title: '¡Actualizada!', text: 'Clase actualizada correctamente.', icon: 'success', confirmButtonColor: '#0f172a' });
        } else {
            await api.post('/admin/clases', payload);
            Swal.fire({ title: '¡Clase Creada!', text: 'Clase guardada exitosamente.', icon: 'success', confirmButtonColor: '#0f172a' });
        }
        setIsModalOpen(false);
        fetchDatosInit(); 
    } catch (error) {
        Swal.fire({ title: 'Error', text: error.response?.data?.error || 'No se pudo guardar la clase.', icon: 'error', confirmButtonColor: '#0f172a' });
    }
  };

  return (
    <div className="p-4 md:p-10 font-sans min-h-screen bg-gray-50 relative">
      <header className="mb-8 md:mb-10 flex flex-col md:flex-row md:justify-between md:items-end gap-4 border-b border-gray-100 pb-6 md:pb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-serif font-bold text-slate-900">Gestión de Clases</h1>
          <p className="text-gray-500 mt-1 md:mt-2 text-xs md:text-sm tracking-wide uppercase font-semibold">Configura las clases públicas de la academia</p>
        </div>
        <button onClick={handleNuevaClase} className="w-full md:w-auto px-6 py-3 bg-slate-900 text-white text-xs font-bold tracking-widest uppercase hover:bg-black transition-all shadow-md active:scale-95">
          + Nueva Clase
        </button>
      </header>

      {/* --- VISTA MÓVIL: TARJETAS --- */}
      <div className="grid grid-cols-1 gap-4 md:hidden">
        {clases.map((clase) => (
          <div key={clase.id} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col gap-4">
            
            <div className="flex justify-between items-start border-b border-gray-100 pb-3">
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Clase</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{clase.nombre}</p>
              </div>
              <div>
                <span className="inline-block px-3 py-1 bg-green-50 text-green-700 border border-green-200 rounded-full text-[10px] font-bold tracking-wider">
                  {clase.estado}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Horario</p>
                <p className="text-xs text-slate-700 mt-0.5 uppercase tracking-wider italic">{clase.horario}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Maestro</p>
                <p className="text-xs font-bold text-slate-900 mt-0.5 leading-tight">Prof. {clase.maestro}</p>
              </div>
            </div>

            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 flex justify-between">
                <span>Ocupación</span>
                <span className="text-slate-700">{clase.cupoOcupado} / {clase.cupoTotal}</span>
              </p>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 ${clase.cupoOcupado >= clase.cupoTotal ? 'bg-red-500' : 'bg-green-500'}`} 
                  style={{ width: `${Math.min((clase.cupoOcupado / clase.cupoTotal) * 100, 100)}%` }}
                ></div>
              </div>
            </div>

            <div className="flex justify-between items-end border-t border-gray-100 pt-3">
              <div className="text-xs text-slate-600 space-y-1 font-medium">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Tarifas (MXN)</p>
                <p><span className="font-bold text-slate-900">Mes:</span> ${clase.precios.mensual}</p>
                <p><span className="font-bold text-slate-900">Suelta:</span> ${clase.precios.suelta}</p>
              </div>
              {/* --- BOTONES MÓVIL --- */}
              <div className="flex gap-4">
                <button 
                  onClick={() => handleArchivar(clase.id)} 
                  className="text-[11px] font-bold text-red-500 border-b border-transparent hover:border-red-500 transition-colors uppercase tracking-widest active:scale-95"
                >
                  Archivar
                </button>
                <button 
                  onClick={() => handleEditar(clase)} 
                  className="text-[11px] font-bold text-slate-900 border-b border-slate-900 pb-0.5 hover:text-gray-600 transition-colors uppercase tracking-widest active:scale-95"
                >
                  Editar
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* --- VISTA ESCRITORIO: TABLA --- */}
      <div className="hidden md:block bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-50 border-b border-gray-200 text-xs uppercase tracking-widest text-gray-400 font-bold">
            <tr>
              <th className="px-6 py-4">Clase / Maestro</th>
              <th className="px-6 py-4 text-center">Ocupación</th>
              <th className="px-6 py-4">Tarifas (MXN)</th>
              <th className="px-6 py-4">Estado</th>
              <th className="px-6 py-4 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {clases.map((clase) => (
              <tr key={clase.id} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-slate-900">{clase.nombre}</p>
                  <p className="text-[11px] text-gray-500 mt-1 uppercase tracking-wider italic">{clase.horario}</p>
                  <p className="text-xs text-slate-600 font-medium mt-1">Prof. {clase.maestro}</p>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-bold text-slate-700 mb-1">{clase.cupoOcupado} / {clase.cupoTotal}</span>
                    <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${clase.cupoOcupado >= clase.cupoTotal ? 'bg-red-500' : 'bg-green-500'}`} 
                        style={{ width: `${Math.min((clase.cupoOcupado / clase.cupoTotal) * 100, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-xs text-slate-600 space-y-1 font-medium">
                    <p><span className="font-bold text-slate-900">Mes:</span> ${clase.precios.mensual}</p>
                    <p><span className="font-bold text-slate-900">Suelta:</span> ${clase.precios.suelta}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="inline-block px-3 py-1 bg-green-50 text-green-700 border border-green-200 rounded-full text-[10px] font-bold tracking-wider">{clase.estado}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  {/* --- BOTONES ESCRITORIO --- */}
                  <div className="flex justify-end items-center gap-4">
                    <button 
                      onClick={() => handleArchivar(clase.id)} 
                      className="text-[11px] font-bold text-red-500 border-b border-transparent hover:border-red-500 transition-colors uppercase tracking-widest"
                    >
                      Archivar
                    </button>
                    <button 
                      onClick={() => handleEditar(clase)} 
                      className="text-[11px] font-bold text-slate-900 border-b border-transparent hover:border-slate-900 transition-colors uppercase tracking-widest"
                    >
                      Editar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* --- MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-5 md:px-8 md:py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 sticky top-0 z-10">
              <h2 className="text-lg md:text-xl font-serif font-bold text-slate-900">{claseEditandoId ? 'Editar Clase' : 'Crear Nueva Clase'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-red-500 transition-colors font-bold text-xl">✕</button>
            </div>
            
            <form onSubmit={handleGuardarClase} className="p-6 md:p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div className="md:col-span-2">
                  <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Nombre de la Clase</label>
                  <input required type="text" name="nombre" value={formData.nombre} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm" placeholder="Ej. Bachata Sensual Intermedios" />
                </div>
                
                <div className="md:col-span-2 border border-gray-200 rounded-xl p-4 md:p-6 bg-gray-50">
                  <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-800 mb-4">Gestor de Horarios</label>
                  <div className="flex flex-col sm:flex-row gap-3 mb-6">
                    <select value={nuevoHorario.dia} onChange={(e) => setNuevoHorario({...nuevoHorario, dia: e.target.value})} className="w-full sm:w-1/3 px-4 py-3 sm:py-2 rounded-lg border border-gray-300 text-sm bg-white">
                      {['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'].map(d => (<option key={d} value={d}>{d}</option>))}
                    </select>
                    <input type="text" value={nuevoHorario.hora} onChange={(e) => setNuevoHorario({...nuevoHorario, hora: e.target.value})} placeholder="Ej. 19:00 - 20:30" className="w-full sm:flex-1 px-4 py-3 sm:py-2 rounded-lg border border-gray-300 text-sm" />
                    <button type="button" onClick={handleAgregarHorario} className="w-full sm:w-auto px-4 py-3 sm:py-2 bg-slate-900 text-white rounded-lg text-sm font-bold hover:bg-black active:scale-95 transition-transform">Añadir</button>
                  </div>
                  <div className="space-y-2">
                    {horariosTemp.length === 0 ? (<p className="text-xs text-gray-500 italic">No hay horarios agregados aún.</p>) : (
                      horariosTemp.map((h, i) => (
                        <div key={h.idTemp || i} className="flex justify-between items-center bg-white p-3 rounded-lg border border-gray-200">
                          <span className="text-sm font-bold text-slate-800">{h.dia} <span className="font-normal text-gray-500 ml-2">{h.hora}</span></span>
                          <button type="button" onClick={() => handleEliminarHorario(h.idTemp)} className="text-red-500 text-xs font-bold uppercase tracking-wider hover:text-red-700">Quitar</button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Descripción (Pública)</label>
                  <textarea required rows="2" name="descripcion" value={formData.descripcion} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm resize-none" placeholder="Describe lo que aprenderán..."></textarea>
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Maestro Asignado</label>
                  <select required name="maestroId" value={formData.maestroId} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 text-sm bg-white font-medium text-slate-700">
                    <option value="">Selecciona un maestro...</option>
                    {listaMaestros.map(maestro => (<option key={maestro.id} value={maestro.id}>{maestro.nombre}</option>))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4 md:col-span-2">
                  <div>
                    <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Cupo por Clase</label>
                    <input required type="number" name="cupoTotal" value={formData.cupoTotal} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 text-sm" placeholder="20" />
                  </div>
                  <div>
                    <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Límite Sueltas</label>
                    <input required type="number" name="limiteSueltas" value={formData.limiteSueltas} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 text-sm" placeholder="5" />
                  </div>
                </div>

                <div className="md:col-span-2 border-t border-gray-100 pt-6">
                  <h3 className="text-[11px] md:text-sm font-bold text-slate-900 uppercase tracking-widest mb-4">Precios (MXN)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Mensualidad</label>
                      <input required type="number" step="0.01" name="precioMensual" value={formData.precioMensual} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 text-sm" placeholder="$ 800" />
                    </div>
                    <div>
                      <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Clase Suelta</label>
                      <input required type="number" step="0.01" name="precioSuelta" value={formData.precioSuelta} onChange={handleChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 text-sm" placeholder="$ 150" />
                    </div>
                  </div>
                </div>

              </div>
              <div className="flex justify-end gap-3 md:gap-4 pt-6 border-t border-gray-100">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 md:px-6 py-3 text-slate-500 text-[10px] md:text-xs font-bold uppercase hover:text-slate-900">Cancelar</button>
                <button type="submit" className="px-4 md:px-6 py-3 bg-slate-900 text-white text-[10px] md:text-xs font-bold uppercase hover:bg-black transition-all shadow-md active:scale-95">{claseEditandoId ? 'Actualizar Clase' : 'Guardar Clase'}</button>
              </div>
            </form>

          </div>
        </div>
      )}
    </div>
  );
};