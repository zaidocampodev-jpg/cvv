import { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import api from '../services/api';

export const AdminMaestros = () => {
  const [listaMaestros, setListaMaestros] = useState([]);
  const [formMaestro, setFormMaestro] = useState({ nombre: '', correo: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const fetchMaestros = async () => {
    try {
      const { data } = await api.get('/auth/admin/maestros');
      setListaMaestros(data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchMaestros();
  }, []);

  const handleInvitar = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const { data } = await api.post('/auth/admin/invitar-maestro', formMaestro);
      Swal.fire({ title: '¡Invitación Enviada!', text: data.mensaje, icon: 'success', confirmButtonColor: '#0f172a' });
      setFormMaestro({ nombre: '', correo: '' });
      setShowForm(false);
      fetchMaestros(); 
    } catch (error) {
      Swal.fire({ title: 'Atención', text: error.response?.data?.error, icon: 'warning', confirmButtonColor: '#0f172a' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEliminarMaestro = async (id, nombre) => {
    Swal.fire({
      title: `¿Eliminar a ${nombre}?`,
      html: `Para confirmar que quiere eliminar a este maestro escriba <b style="color:red;">ELIMINAR</b> en el texto de abajo:`,
      input: 'text',
      position: 'top',
      backdrop: false,
      width: '380px',
      customClass: {
        popup: 'mt-20 shadow-2xl border border-gray-200 rounded-2xl',
        title: 'text-lg text-slate-800 font-serif',
        confirmButton: 'bg-red-500 text-white text-xs font-bold px-5 py-2 uppercase tracking-widest rounded',
        cancelButton: 'bg-slate-900 text-white text-xs font-bold px-5 py-2 uppercase tracking-widest rounded',
      },
      inputAttributes: { autocapitalize: 'off', placeholder: 'ELIMINAR' },
      showCancelButton: true,
      confirmButtonText: 'Borrar',
      cancelButtonText: 'Cancelar',
      showLoaderOnConfirm: true,
      preConfirm: (texto) => {
        if (texto !== 'ELIMINAR') {
          Swal.showValidationMessage('Debes escribir ELIMINAR en mayúsculas');
          return false;
        }
        return api.delete(`/auth/admin/maestros/${id}`)
          .then(response => response.data)
          .catch(error => {
            Swal.showValidationMessage(`Error: ${error.response?.data?.error || 'No se pudo eliminar'}`);
          });
      },
      allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire({ 
            title: 'Maestro eliminado', 
            icon: 'success', 
            position: 'top', 
            toast: true, 
            showConfirmButton: false, 
            timer: 3000 
        });
        fetchMaestros();
      }
    });
  };

  return (
    <div className="p-8 md:p-12 font-sans min-h-screen bg-gray-50/30">
      
      {/* Cabecera */}
      <header className="mb-10">
        <h1 className="text-4xl font-serif font-bold text-[#0f172a] tracking-tight">Gestión de Maestros</h1>
        <p className="text-gray-500 mt-2 text-sm tracking-widest uppercase font-semibold">
          Crea invitaciones o elimina personal activo
        </p>
      </header>

      {/* Botón de Acción Principal */}
      <div className="mb-8">
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-[#0f172a] text-white text-xs font-bold px-8 py-3.5 uppercase tracking-widest hover:bg-black transition-all rounded-sm"
        >
          {showForm ? '− CANCELAR INVITACIÓN' : '+ INVITAR NUEVO MAESTRO'}
        </button>
      </div>

      {/* Formulario Desplegable */}
      {showForm && (
        <div className="mb-10 bg-white p-6 md:p-8 rounded-xl shadow-sm border border-gray-200 transition-all">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-widest mb-6">Datos del nuevo maestro</h3>
          <form onSubmit={handleInvitar} className="flex flex-col md:flex-row gap-6 items-end">
            <div className="w-full md:flex-1">
              <label className="block text-[10px] uppercase tracking-widest font-bold text-gray-500 mb-2">Nombre Completo</label>
              <input required type="text" value={formMaestro.nombre} onChange={(e) => setFormMaestro({...formMaestro, nombre: e.target.value})} className="w-full px-4 py-3 rounded border border-gray-200 text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900 transition-all bg-white" placeholder="Ej. Juan Pérez" />
            </div>
            <div className="w-full md:flex-1">
              <label className="block text-[10px] uppercase tracking-widest font-bold text-gray-500 mb-2">Correo Electrónico</label>
              <input required type="email" value={formMaestro.correo} onChange={(e) => setFormMaestro({...formMaestro, correo: e.target.value})} className="w-full px-4 py-3 rounded border border-gray-200 text-sm focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900 transition-all bg-white" placeholder="juan@estilolatino.com" />
            </div>
            <div className="w-full md:w-auto">
              <button type="submit" disabled={isLoading} className="w-full md:w-auto px-8 py-3 bg-[#0f172a] text-white text-xs font-bold uppercase tracking-widest rounded hover:bg-black transition-all disabled:opacity-70">
                {isLoading ? 'ENVIANDO...' : 'MANDAR INVITACIÓN'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Lista de Maestros con el botón original */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-gray-50/50 border-b border-gray-100">
          <h3 className="text-[11px] font-bold text-slate-600 uppercase tracking-widest">Maestros Registrados</h3>
        </div>
        
        <div className="divide-y divide-gray-100">
          {listaMaestros.length === 0 ? (
            <p className="py-12 text-center text-sm text-gray-400 italic">No hay maestros registrados todavía.</p>
          ) : (
            listaMaestros.map(m => (
              <div key={m.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-6 hover:bg-gray-50/50 transition-colors gap-4">
                <div>
                  <p className="font-bold text-slate-900 text-sm mb-1">{m.nombre}</p>
                  <p className="text-[11px] text-gray-500 font-mono tracking-wider uppercase">{m.correo}</p>
                </div>
                <div>
                  <button 
                    onClick={() => handleEliminarMaestro(m.id, m.nombre)}
                    className="text-[10px] font-bold text-red-500 hover:text-white hover:bg-red-500 border border-red-200 px-5 py-2.5 rounded uppercase tracking-widest transition-all w-full sm:w-auto"
                  >
                    Eliminar Cuenta
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
};