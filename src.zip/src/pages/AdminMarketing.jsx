import { useState } from 'react';
import Swal from 'sweetalert2';
import api from '../services/api';

export const AdminMarketing = () => {
  const [destinatarios, setDestinatarios] = useState('todos');
  const [asunto, setAsunto] = useState('');
  const [tipoPlantilla, setTipoPlantilla] = useState(''); 
  
  const [varsPlantilla, setVarsPlantilla] = useState({
    titulo: '',
    mensaje: '',
    botonTexto: 'Ver más',
    codigoPromo: '',
    fechaCaducidad: ''
  });

  const handleVarChange = (e) => {
    setVarsPlantilla({ ...varsPlantilla, [e.target.name]: e.target.value });
  };

  const generarHTMLBoletin = () => `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; color: #333; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
      <div style="background-color: #0f172a; padding: 30px; text-align: center;">
        <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-style: italic;">Estilo Latino</h1>
      </div>
      <div style="padding: 40px 30px;">
        <h2 style="color: #0f172a; text-align: center; border-bottom: 2px solid #f1f5f9; padding-bottom: 15px; margin-top: 0;">
          ${varsPlantilla.titulo || 'Boletín Oficial'}
        </h2>
        <p style="font-size: 16px; line-height: 1.6; color: #475569; margin-top: 20px;">
          ${varsPlantilla.mensaje.replace(/\n/g, '<br>') || 'Novedades de la academia...'}
        </p>
        <div style="text-align: center; margin: 40px 0 20px 0;">
          <a href="https://academiaestilolatino.com" style="background-color: #0f172a; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">
            ${varsPlantilla.botonTexto || 'Visitar Portal'}
          </a>
        </div>
      </div>
      <div style="background-color: #f8fafc; padding: 20px; text-align: center; border-top: 1px solid #e2e8f0;">
        <p style="font-size: 12px; color: #64748b; margin: 0;">© 2026 Academia Estilo Latino. Todos los derechos reservados.</p>
      </div>
    </div>
  `;

  const generarHTMLPromocion = () => `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; color: #333; text-align: center; border: 1px solid #fecdd3; border-radius: 8px; overflow: hidden;">
      <div style="background-color: #be123c; padding: 30px;">
        <h1 style="color: #ffffff; margin: 0; font-size: 28px; text-transform: uppercase; letter-spacing: 2px;">
          ${varsPlantilla.titulo || '¡OFERTA EXCLUSIVA!'}
        </h1>
      </div>
      <div style="padding: 40px 30px;">
        <p style="font-size: 18px; margin-bottom: 30px; color: #4c0519; font-weight: bold;">
          ${varsPlantilla.mensaje || 'Aprovecha esta promoción especial para ti.'}
        </p>
        <div style="background-color: #fff1f2; border: 2px dashed #f43f5e; padding: 25px; margin: 0 auto 30px auto; border-radius: 8px; max-width: 400px;">
          <p style="margin: 0 0 10px 0; font-size: 12px; color: #9f1239; text-transform: uppercase; font-weight: bold; letter-spacing: 1px;">Código de Descuento:</p>
          <h2 style="margin: 0; font-size: 36px; color: #e11d48; letter-spacing: 4px;">
            ${varsPlantilla.codigoPromo || 'CÓDIGO'}
          </h2>
        </div>
        <p style="font-size: 13px; color: #881337; font-style: italic;">
          Válido hasta el ${varsPlantilla.fechaCaducidad || 'cierre de mes'}.
        </p>
        <div style="margin-top: 35px;">
          <a href="https://academiaestilolatino.com" style="background-color: #e11d48; color: white; padding: 16px 32px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 15px; text-transform: uppercase; letter-spacing: 1px;">
            Canjear Ahora
          </a>
        </div>
      </div>
    </div>
  `;

  const handleEnviar = (e) => {
    e.preventDefault();
    
    if (!tipoPlantilla) {
      Swal.fire({ icon: 'error', title: 'Error', text: 'Selecciona una plantilla primero.', confirmButtonColor: '#0f172a' });
      return;
    }

    const cuerpoHtml = tipoPlantilla === 'boletin' ? generarHTMLBoletin() : generarHTMLPromocion();
    
    Swal.fire({
      title: '¿Enviar campaña masiva?',
      text: `Estás a punto de enviar este correo a los alumnos.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#0f172a',
      cancelButtonColor: '#94a3b8',
      confirmButtonText: 'Sí, enviar ahora',
      cancelButtonText: 'Cancelar',
      reverseButtons: true
    }).then(async (result) => {
      if (result.isConfirmed) {
        
        Swal.fire({
          title: 'Enviando correos...',
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
          }
        });

        try {
          await api.post('/admin/marketing/enviar', {
            asunto: asunto,
            cuerpoHtml: cuerpoHtml
          });

          Swal.fire({
            title: '¡Campaña Enviada!',
            text: 'El correo se ha enviado exitosamente.',
            icon: 'success',
            confirmButtonColor: '#0f172a',
          });
          
          setAsunto('');
          setTipoPlantilla('');
          setVarsPlantilla({ titulo: '', mensaje: '', botonTexto: 'Ver más', codigoPromo: '', fechaCaducidad: '' });
        } catch (error) {
          Swal.fire({
            title: 'Error',
            text: error.response?.data?.error || 'Hubo un problema al enviar la campaña de marketing.',
            icon: 'error',
            confirmButtonColor: '#0f172a',
          });
        }
      }
    });
  };

  return (
    // Padding responsivo: pequeño en celular (p-4), grande en PC (md:p-10)
    <div className="p-4 sm:p-6 md:p-10 font-sans bg-gray-50 min-h-screen">
      
      {/* Márgenes del header responsivos */}
      <header className="mb-6 md:mb-10 border-b border-gray-100 pb-4 md:pb-8">
        <h1 className="text-2xl md:text-3xl font-serif font-bold text-slate-900">Marketing Automatizado</h1>
        <p className="text-gray-500 mt-2 text-xs md:text-sm tracking-wide uppercase font-semibold">
          Envía correos masivos y promociones a tus alumnos
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        
        {/* Padding interior de la tarjeta principal ajustado */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-5 md:p-8">
          
          <h2 className="text-lg md:text-xl font-serif font-bold text-slate-900 mb-6 border-b border-gray-100 pb-4">
            Diseñador de Campaña
          </h2>

          <form onSubmit={handleEnviar} className="space-y-6 md:space-y-8">
            
            <div className="space-y-4">
              <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">
                1. Selecciona una plantilla
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div 
                  onClick={() => setTipoPlantilla('boletin')}
                  className={`cursor-pointer border-2 rounded-xl p-4 transition-all ${tipoPlantilla === 'boletin' ? 'border-slate-900 bg-slate-50' : 'border-gray-200 hover:border-slate-300'}`}
                >
                  <div className="w-full h-24 bg-slate-900 rounded flex flex-col items-center justify-center p-2 mb-3">
                    <div className="w-16 h-2 bg-slate-700 rounded mb-2"></div>
                    <div className="w-24 h-1 bg-slate-700 rounded mb-1"></div>
                    <div className="w-20 h-1 bg-slate-700 rounded"></div>
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm">Boletín Informativo</h3>
                  <p className="text-xs text-gray-500 mt-1">Ideal para noticias, avisos y comunicados generales.</p>
                </div>

                <div 
                  onClick={() => setTipoPlantilla('promocion')}
                  className={`cursor-pointer border-2 rounded-xl p-4 transition-all ${tipoPlantilla === 'promocion' ? 'border-rose-600 bg-rose-50' : 'border-gray-200 hover:border-rose-200'}`}
                >
                  <div className="w-full h-24 bg-rose-600 rounded flex flex-col items-center justify-center p-2 mb-3">
                    <div className="w-20 h-3 bg-rose-800 rounded mb-3"></div>
                    <div className="w-32 h-6 border-2 border-dashed border-rose-300 rounded bg-rose-50 flex items-center justify-center">
                      <div className="w-12 h-2 bg-rose-300 rounded"></div>
                    </div>
                  </div>
                  <h3 className="font-bold text-rose-700 text-sm">Cupón de Promoción</h3>
                  <p className="text-xs text-gray-500 mt-1">Diseño llamativo con código de descuento destacado.</p>
                </div>

              </div>
            </div>

            {tipoPlantilla && (
              <div className="bg-gray-50 p-4 md:p-6 rounded-xl border border-gray-200 space-y-6 animate-fade-in">
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Destinatarios</label>
                  <select 
                    value={destinatarios}
                    onChange={(e) => setDestinatarios(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white focus:outline-none focus:border-slate-900 text-sm"
                  >
                    <option value="todos">Todos los alumnos registrados (Base histórica)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Asunto del Correo</label>
                  <input required type="text" value={asunto} onChange={(e) => setAsunto(e.target.value)} className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white focus:outline-none focus:border-slate-900 text-sm" placeholder="Ej. ¡Aviso importante sobre las clases!" />
                </div>

                <div className="border-t border-gray-200 pt-6 mt-2">
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-4">Contenido del Correo</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs uppercase tracking-widest font-bold text-gray-500 mb-1">Título Principal</label>
                      <input required type="text" name="titulo" value={varsPlantilla.titulo} onChange={handleVarChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-sm" placeholder={tipoPlantilla === 'boletin' ? "Ej. Novedades de Abril" : "Ej. ¡SÚPER OFERTA!"} />
                    </div>
                    
                    <div>
                      <label className="block text-xs uppercase tracking-widest font-bold text-gray-500 mb-1">Mensaje o Descripción</label>
                      <textarea required rows="4" name="mensaje" value={varsPlantilla.mensaje} onChange={handleVarChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-sm resize-none" placeholder="Escribe aquí los detalles..."></textarea>
                    </div>

                    {tipoPlantilla === 'boletin' && (
                      <div>
                        <label className="block text-xs uppercase tracking-widest font-bold text-gray-500 mb-1">Texto del Botón</label>
                        <input required type="text" name="botonTexto" value={varsPlantilla.botonTexto} onChange={handleVarChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-sm" placeholder="Ej. Reservar mi lugar" />
                      </div>
                    )}

                    {tipoPlantilla === 'promocion' && (
                      // Grid dinámico: 1 columna en celular, 2 columnas en pantallas medianas
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs uppercase tracking-widest font-bold text-rose-500 mb-1">Código Promocional</label>
                          <input required type="text" name="codigoPromo" value={varsPlantilla.codigoPromo} onChange={handleVarChange} className="w-full px-4 py-3 rounded-lg border border-rose-200 bg-rose-50 text-rose-700 font-bold uppercase text-sm" placeholder="Ej. VERANO20" />
                        </div>
                        <div>
                          <label className="block text-xs uppercase tracking-widest font-bold text-gray-500 mb-1">Fecha de Caducidad</label>
                          <input required type="text" name="fechaCaducidad" value={varsPlantilla.fechaCaducidad} onChange={handleVarChange} className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white text-sm" placeholder="Ej. 30 de Mayo" />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Flexbox ajustado: botón ancho total en móvil */}
            <div className="pt-4 flex flex-col sm:flex-row justify-end">
              <button 
                type="submit" 
                disabled={!tipoPlantilla}
                className={`w-full sm:w-auto px-8 py-3.5 text-xs font-bold tracking-widest uppercase transition-all shadow-md rounded-lg ${!tipoPlantilla ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-slate-900 text-white hover:bg-black active:scale-95'}`}
              >
                Enviar Campaña
              </button>
            </div>
          </form>
        </div>

        {/* Tarjeta lateral con padding ajustado */}
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-xl shadow-sm p-5 md:p-6 text-white border border-slate-800">
            <h3 className="text-xs uppercase tracking-widest font-bold text-gray-400 mb-3">
              Consejo de Diseño
            </h3>
            <p className="text-sm font-light text-gray-300 leading-relaxed mb-4">
              Selecciona una tarjeta visual para cargar una estructura profesional. Solo debes rellenar los datos del formulario y nosotros nos encargaremos de generar el código por detrás para que los correos luzcan increíbles.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};