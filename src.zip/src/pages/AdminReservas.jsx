import { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import api from '../services/api';

export const AdminReservas = () => {
  const [reservas, setReservas] = useState([]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formDataManual, setFormDataManual] = useState({
    alumno: '',
    claseId: '',
    tipo: 'MENSUALIDAD',
    monto: ''
  });

  const [listaClases, setListaClases] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const resClases = await api.get('/public/clases');
        setListaClases(resClases.data);

        const resReservas = await api.get('/admin/reservas');
        const mappedReservas = resReservas.data.map(r => ({
          idOriginal: r.id,
          id: r.codigoUnico,
          alumno: `${r.nombreAlumno} ${r.apellidos || ''}`,
          clase: r.clase?.nombre || 'Clase no especificada',
          tipo: r.tipoPaquete,
          estatus: r.estado,
          caducidad: r.estado === 'PENDIENTE' ? 'Pronto' : '-',
          monto: r.tipoPaquete === 'MENSUALIDAD' ? '800,00 $' : '150,00 $'
        }));
        setReservas(mappedReservas);
      } catch (error) {
        console.error(error);
      }
    };
    fetchData();
  }, []);

  const confirmarPago = (idReserva) => {
    Swal.fire({
      title: '¿Confirmar pago?',
      text: `Estás a punto de validar el pago de la reserva ${idReserva}`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#0f172a',
      cancelButtonColor: '#94a3b8',
      confirmButtonText: 'Sí, confirmar',
      cancelButtonText: 'Cancelar',
      reverseButtons: true
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const reservaDDBB = reservas.find(r => r.id === idReserva);
          if (reservaDDBB && reservaDDBB.idOriginal) {
            await api.put(`/admin/reservas/${reservaDDBB.idOriginal}/confirmar`);
          }

          setReservas(prevReservas => 
            prevReservas.map(reserva => 
              reserva.id === idReserva 
                ? { ...reserva, estatus: 'PAGADO', caducidad: '-' } 
                : reserva
            )
          );

          Swal.fire({
            title: '¡Confirmado!',
            text: 'El pago ha sido registrado correctamente.',
            icon: 'success',
            confirmButtonColor: '#0f172a',
          });
        } catch (error) {
          Swal.fire({
            title: 'Error',
            text: 'No se pudo confirmar el pago.',
            icon: 'error',
            confirmButtonColor: '#0f172a',
          });
        }
      }
    });
  };

  const handleChangeManual = (e) => {
    const { name, value } = e.target;
    setFormDataManual(prev => ({ ...prev, [name]: value }));

    if (name === 'claseId' || name === 'tipo') {
      const claseSel = listaClases.find(c => c.id.toString() === (name === 'claseId' ? value : formDataManual.claseId));
      if (claseSel) {
        const nuevoMonto = formDataManual.tipo === 'MENSUALIDAD' ? claseSel.precioMensual : claseSel.precioSuelta;
        setFormDataManual(prev => ({ ...prev, monto: nuevoMonto }));
      }
    }
  };

  const handleGuardarRegistroManual = (e) => {
    e.preventDefault();
    setIsModalOpen(false);

    const claseSel = listaClases.find(c => c.id.toString() === formDataManual.claseId);
    const nombreClase = claseSel ? claseSel.nombre : 'Clase Desconocida';

    const nuevaReserva = {
      idOriginal: Date.now(),
      id: `#MANUAL-${Date.now().toString().slice(-3)}`,
      alumno: formDataManual.alumno,
      clase: nombreClase,
      tipo: formDataManual.tipo,
      estatus: 'PAGADO',
      caducidad: '-',
      monto: `${formDataManual.monto},00 $`
    };

    setReservas([nuevaReserva, ...reservas]);

    Swal.fire({
      title: '¡Registro Exitoso!',
      text: `El alumno ${formDataManual.alumno} ha sido inscrito manualmente.`,
      icon: 'success',
      confirmButtonColor: '#0f172a',
    });

    setFormDataManual({ alumno: '', claseId: '', tipo: 'MENSUALIDAD', monto: '' });
  };

  return (
    <div className="p-4 md:p-10 font-sans min-h-screen bg-gray-50 relative">
      <header className="mb-8 md:mb-10 flex flex-col md:flex-row md:justify-between md:items-end gap-4 border-b border-gray-100 pb-6 md:pb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-serif font-bold text-slate-900">Reservas y Pagos</h1>
          <p className="text-gray-500 mt-1 md:mt-2 text-xs md:text-sm tracking-wide uppercase font-semibold">
            Aprueba pagos o registra alumnos manualmente
          </p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="w-full md:w-auto px-6 py-3 bg-slate-900 text-white text-xs font-bold tracking-widest uppercase hover:bg-black transition-all shadow-md active:scale-95"
        >
          + Manual de Registro
        </button>
      </header>

      {/* --- VISTA MÓVIL: TARJETAS (Oculto en md para arriba) --- */}
      <div className="grid grid-cols-1 gap-4 md:hidden">
        {reservas.map((reserva) => (
          <div key={reserva.idOriginal} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex flex-col gap-4">
            
            <div className="flex justify-between items-start border-b border-gray-100 pb-3">
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">ID Reserva</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{reserva.id}</p>
              </div>
              <div className="text-right">
                {reserva.estatus === 'PENDIENTE' ? (
                  <>
                    <span className="inline-block px-3 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-[10px] font-bold tracking-wider">
                      PENDIENTE
                    </span>
                    <p className="text-[10px] text-red-500 mt-1 font-medium italic">Expira: {reserva.caducidad}</p>
                  </>
                ) : (
                  <span className="inline-block px-3 py-1 bg-green-50 text-green-700 border border-green-200 rounded-full text-[10px] font-bold tracking-wider">
                    PAGADO
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Alumno</p>
                <p className="text-sm text-slate-700 font-medium mt-0.5">{reserva.alumno}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Clase / Tipo</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5 leading-tight">{reserva.clase}</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-wide mt-1 italic">{reserva.tipo}</p>
              </div>
            </div>

            <div className="flex justify-between items-center border-t border-gray-100 pt-3">
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Monto</p>
                <p className="text-sm font-semibold text-slate-700 mt-0.5">{reserva.monto}</p>
              </div>
              <div>
                {reserva.estatus === 'PENDIENTE' ? (
                  <button 
                    onClick={() => confirmarPago(reserva.id)}
                    className="text-[11px] font-bold text-green-600 border-b border-green-600 pb-0.5 hover:text-green-800 hover:border-green-800 transition-colors uppercase tracking-widest active:scale-95"
                  >
                    Confirmar Pago
                  </button>
                ) : (
                  <span className="text-[11px] font-bold text-gray-300 uppercase tracking-widest">
                    Completado
                  </span>
                )}
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* --- VISTA ESCRITORIO: TABLA (Oculto en móviles) --- */}
      <div className="hidden md:block bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 border-b border-gray-200 text-xs uppercase tracking-widest text-gray-400 font-bold">
              <tr>
                <th className="px-6 py-4">ID Reserva</th>
                <th className="px-6 py-4">Alumnos</th>
                <th className="px-6 py-4">Clase / Tipo</th>
                <th className="px-6 py-4">Monto</th>
                <th className="px-6 py-4">Estatus</th>
                <th className="px-6 py-4 text-right">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {reservas.map((reserva) => (
                <tr key={reserva.idOriginal} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4 font-bold text-slate-900 text-sm">{reserva.id}</td>
                  <td className="px-6 py-4 text-sm text-slate-700 font-medium">{reserva.alumno}</td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-bold text-slate-900">{reserva.clase}</p>
                    <p className="text-xs text-gray-500 uppercase tracking-wide mt-1 italic">{reserva.tipo}</p>
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-slate-700">{reserva.monto}</td>
                  <td className="px-6 py-4">
                    {reserva.estatus === 'PENDIENTE' ? (
                      <div>
                        <span className="inline-block px-3 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-[10px] font-bold tracking-wider">
                          PENDIENTE
                        </span>
                        <p className="text-[10px] text-red-500 mt-1 font-medium italic">Expira en {reserva.caducidad}</p>
                      </div>
                    ) : (
                      <span className="inline-block px-3 py-1 bg-green-50 text-green-700 border border-green-200 rounded-full text-[10px] font-bold tracking-wider">
                        PAGADO
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    {reserva.estatus === 'PENDIENTE' ? (
                      <button 
                        onClick={() => confirmarPago(reserva.id)}
                        className="text-[11px] font-bold text-green-600 border-b border-green-600 pb-0.5 hover:text-green-800 hover:border-green-800 transition-colors uppercase tracking-widest active:scale-95"
                      >
                        Confirmar
                      </button>
                    ) : (
                      <span className="text-[11px] font-bold text-gray-300 uppercase tracking-widest">
                        Completado
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
            
            <div className="px-6 py-5 md:px-8 md:py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h2 className="text-lg md:text-xl font-serif font-bold text-slate-900">Registro Manual en Recepción</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-red-500 transition-colors font-bold text-xl">✕</button>
            </div>

            <form onSubmit={handleGuardarRegistroManual} className="p-6 md:p-8 space-y-5">
                <p className="text-[11px] md:text-xs text-gray-500 border-l-4 border-amber-400 pl-4 bg-amber-50 py-3 rounded-r-lg leading-relaxed">
                    Utiliza este formulario cuando un alumno pague en efectivo directamente en la academia. El estatus se fijará automáticamente como <strong>PAGADO</strong>.
                </p>

              <div>
                <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Nombre Completo del Alumno</label>
                <input required type="text" name="alumno" value={formDataManual.alumno} onChange={handleChangeManual} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm font-medium" placeholder="Ej. Pedro Páramo" />
              </div>

              <div>
                <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Clase a Inscribir</label>
                <select required name="claseId" value={formDataManual.claseId} onChange={handleChangeManual} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm bg-white font-medium text-slate-700">
                  <option value="">Selecciona la clase...</option>
                  {listaClases.map(clase => (
                      <option key={clase.id} value={clase.id}>{clase.nombre}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Tipo de Pago</label>
                    <select required name="tipo" value={formDataManual.tipo} onChange={handleChangeManual} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm bg-white font-medium text-slate-700">
                        <option value="MENSUALIDAD">MENSUALIDAD</option>
                        <option value="CLASE SUELTA">CLASE SUELTA</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] md:text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Monto Recibido ($)</label>
                    <input required type="number" name="monto" value={formDataManual.monto} onChange={handleChangeManual} className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm font-bold text-slate-900 bg-gray-100" placeholder="0" readOnly />
                  </div>
              </div>

              <div className="flex justify-end gap-3 md:gap-4 pt-6 border-t border-gray-100 mt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 md:px-6 py-3 text-slate-500 text-[10px] md:text-xs font-bold tracking-widest uppercase hover:text-slate-900 transition-colors">
                  Cancelar
                </button>
                <button type="submit" className="px-4 md:px-6 py-3 bg-slate-900 text-white text-[10px] md:text-xs font-bold tracking-widest uppercase hover:bg-black transition-all shadow-md active:scale-95">
                  Confirmar
                </button>
              </div>
            </form>

          </div>
        </div>
      )}
    </div>
  );
};