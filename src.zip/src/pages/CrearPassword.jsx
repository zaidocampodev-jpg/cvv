import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import api from '../services/api';

export const CrearPassword = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token'); // Extraemos el token de la URL
  const navigate = useNavigate();

  const [password, setPassword] = useState('');
  const [confirmarPassword, setConfirmarPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      Swal.fire({ title: 'Enlace inválido', text: 'No se encontró el token de seguridad.', icon: 'error', confirmButtonColor: '#0f172a' });
      return;
    }

    if (password.length < 6) {
      Swal.fire({ title: 'Contraseña corta', text: 'La contraseña debe tener al menos 6 caracteres.', icon: 'warning', confirmButtonColor: '#0f172a' });
      return;
    }

    if (password !== confirmarPassword) {
      Swal.fire({ title: 'Las contraseñas no coinciden', text: 'Asegúrate de escribir exactamente la misma contraseña en ambos campos.', icon: 'error', confirmButtonColor: '#0f172a' });
      return;
    }

    setIsLoading(true);

    try {
      const { data } = await api.post('/auth/configurar-password', {
        token: token,
        nuevaPassword: password
      });

      Swal.fire({
        title: '¡Éxito!',
        text: data.mensaje || 'Contraseña configurada correctamente.',
        icon: 'success',
        confirmButtonColor: '#0f172a'
      }).then(() => {
        navigate('/');
      });

    } catch (error) {
      Swal.fire({
        title: 'Error',
        text: error.response?.data?.error || 'El enlace ha expirado o ya fue utilizado.',
        icon: 'error',
        confirmButtonColor: '#0f172a'
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 font-sans p-4">
        <div className="bg-white p-8 rounded-xl shadow-xl text-center max-w-md w-full border-t-4 border-red-600">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Enlace Inválido</h2>
          <p className="text-gray-500 mb-6">No se detectó un token de seguridad válido. Por favor, asegúrate de haber hecho clic en el enlace completo enviado a tu correo.</p>
          <button onClick={() => navigate('/')} className="bg-slate-900 text-white px-6 py-2 rounded font-bold uppercase tracking-widest text-xs hover:bg-black">Ir al Login</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 font-sans p-4">
      <div className="bg-white p-10 rounded-2xl shadow-2xl w-full max-w-md border border-gray-100">
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-serif font-bold text-slate-900 italic mb-2">Estilo Latino</h1>
          <h2 className="text-xl font-bold text-slate-700">Configura tu acceso</h2>
          <p className="text-sm text-gray-500 mt-2">Crea una contraseña segura para tu cuenta de maestro.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Nueva Contraseña</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm" 
              placeholder="••••••••" 
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">Confirmar Contraseña</label>
            <input 
              type="password" 
              required
              value={confirmarPassword}
              onChange={(e) => setConfirmarPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:border-slate-900 text-sm" 
              placeholder="••••••••" 
            />
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className={`w-full py-4 text-white text-xs font-bold tracking-widest uppercase transition-all shadow-md rounded-lg mt-4 ${isLoading ? 'bg-slate-400 cursor-not-allowed' : 'bg-slate-900 hover:bg-black active:scale-95'}`}
          >
            {isLoading ? 'Guardando...' : 'Guardar y Continuar'}
          </button>
        </form>

      </div>
    </div>
  );
};