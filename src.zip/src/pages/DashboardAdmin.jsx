import { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LabelList, ResponsiveContainer,
  LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, Legend
} from 'recharts';
import { 
  FaSpinner, FaDollarSign, FaTicketAlt, FaClock, 
  FaChartLine, FaServer, FaEnvelope, FaImage, 
  FaChalkboardTeacher, FaTag, FaCalendarAlt
} from 'react-icons/fa';
import api from '../services/api';

const COLORS = ['#111A24', '#FF4C61', '#475569', '#94A3B8', '#E2E8F0'];

export const DashboardAdmin = () => {
  const [loading, setLoading] = useState(true);
  
  const [data, setData] = useState({
    tarjetas: { reservasPendientes: 0, clasesActivas: 0, ingresosMensuales: 0 },
    graficas: { 
      ocupacionClases: [],
      ingresosHistoricos: [], 
      distribucionPaquetes: [], 
      embudoConversion: [],
      mapaCalorHorarios: [],    
      rendimientoMaestros: [],  
      exitoPromociones: [],      
      medidorBrevo: { enviadosHoy: 0, limiteDiario: 300 },      
      medidorCloudinary: { usoCreditos: 0, limiteCreditos: 25, porcentajeUso: 0 }  
    }
  });

  useEffect(() => {
    fetchEstadisticas();
  }, []);

  const fetchEstadisticas = async () => {
    try {
      const res = await api.get('/admin/estadisticas');
      if (res.data) {
        setData(res.data);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const formatearDinero = (n) => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(n || 0);

  const normalizarTexto = (str) => str ? str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toUpperCase() : "OTROS";

  const paquetesFiltrados = data.graficas.distribucionPaquetes?.filter(paquete => {
    const nombreLower = paquete.nombre?.toLowerCase() || '';
    return nombreLower.includes('mensual') || nombreLower.includes('suelta');
  }) || [];

  const ingresosHistoricosProcesados = data.graficas.ingresosHistoricos?.length === 1 
    ? [{ mes: 'Inicio', ingreso: 0 }, ...data.graficas.ingresosHistoricos] 
    : data.graficas.ingresosHistoricos || [];

  const embudoProcesado = Object.values((data.graficas.embudoConversion || []).reduce((acc, curr) => {
    const estado = curr.estado || 'Desconocido';
    if (!acc[estado]) acc[estado] = { estado, cantidad: 0 };
    acc[estado].cantidad += Number(curr.cantidad || 0);
    return acc;
  }, {})).sort((a, b) => b.cantidad - a.cantidad);

  const maestrosProcesados = Object.values((data.graficas.rendimientoMaestros || []).reduce((acc, curr) => {
    const llave = normalizarTexto(curr.nombre);
    if (!acc[llave]) acc[llave] = { nombre: curr.nombre, ingresosGenerados: 0 };
    acc[llave].ingresosGenerados += Number(curr.ingresosGenerados || 0);
    return acc;
  }, {})).sort((a, b) => b.ingresosGenerados - a.ingresosGenerados);

  const promocionesProcesadas = Object.values((data.graficas.exitoPromociones || []).reduce((acc, curr) => {
    const titulo = curr.titulo || 'Sin Título';
    if (!acc[titulo]) acc[titulo] = { titulo, usosActuales: 0 };
    acc[titulo].usosActuales += Number(curr.usosActuales || 0);
    return acc;
  }, {})).sort((a, b) => b.usosActuales - a.usosActuales);

  const horariosProcesados = Object.values((data.graficas.mapaCalorHorarios || []).reduce((acc, curr) => {
    const horario = curr.horario || 'Sin horario';
    if (!acc[horario]) acc[horario] = { horario, asistencias: 0 };
    acc[horario].asistencias += Number(curr.asistencias || 0);
    return acc;
  }, {})).sort((a, b) => b.asistencias - a.asistencias);

  const porcentajeBrevo = data.graficas.medidorBrevo?.limiteDiario > 0 
    ? Math.min((data.graficas.medidorBrevo.enviadosHoy / data.graficas.medidorBrevo.limiteDiario) * 100, 100) : 0;
  
  const porcentajeCloudinary = data.graficas.medidorCloudinary?.porcentajeUso || 0;

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">
      <FaSpinner className="animate-spin text-[#FF4C61]" size={50} />
    </div>
  );

  return (
    <div className="p-4 md:p-8 font-sans min-h-screen bg-[#F8FAFC] text-slate-900 w-full overflow-hidden">
      
      <header className="mb-8 md:mb-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-serif font-bold tracking-tight text-slate-900 italic">Dashboard</h1>
          <p className="text-slate-400 text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] md:tracking-[0.3em] mt-1">
            Estilo Latino | Control Total
          </p>
        </div>
        <div className="bg-white px-4 py-2 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Conectado a la API</span>
        </div>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8">
        <div className="bg-white p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] shadow-xl shadow-slate-200/60 border border-white relative overflow-hidden group transition-all hover:-translate-y-1">
          <div className="relative z-10">
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Reservas en Espera</h3>
            <p className="text-4xl md:text-6xl font-serif font-bold text-slate-900 mt-2">{data.tarjetas.reservasPendientes}</p>
          </div>
          <FaClock className="absolute -right-4 -bottom-4 text-slate-50 opacity-10 group-hover:opacity-20 transition-opacity" size={120} />
        </div>

        <div className="bg-white p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] shadow-xl shadow-slate-200/60 border border-white relative overflow-hidden group transition-all hover:-translate-y-1">
          <div className="relative z-10">
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Clases Activas</h3>
            <p className="text-4xl md:text-6xl font-serif font-bold text-slate-900 mt-2">{data.tarjetas.clasesActivas}</p>
          </div>
          <FaTicketAlt className="absolute -right-4 -bottom-4 text-slate-50 opacity-10 group-hover:opacity-20 transition-opacity" size={120} />
        </div>

        <div className="bg-slate-900 p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] shadow-2xl shadow-slate-400 border border-slate-800 relative overflow-hidden group transition-all hover:-translate-y-1">
          <div className="relative z-10">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Ingresos del Mes</h3>
            <p className="text-3xl md:text-4xl font-bold text-white mt-4">{formatearDinero(data.tarjetas.ingresosMensuales)}</p>
          </div>
          <FaDollarSign className="absolute -right-4 -bottom-4 text-white opacity-5 group-hover:opacity-10 transition-opacity" size={120} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-10 mb-8">
        
        <div className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Ocupación de Clases (%)</h3>
             <FaChartLine className="text-slate-200" />
          </div>
          <div className="w-full h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.graficas.ocupacionClases} layout="vertical" margin={{ top: 0, right: 40, left: 60, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis dataKey="nombre" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 'bold', fill: '#475569' }} width={90} />
                <Tooltip 
                  cursor={{ fill: '#F8FAFC' }} 
                  contentStyle={{ borderRadius: '15px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                  formatter={(value, name, props) => [
                    `${value}% (${props.payload.inscritos} de ${props.payload.cupoTotal} lugares)`, 
                    'Ocupación'
                  ]} 
                />
                <Bar dataKey="porcentaje" fill="#FF4C61" radius={[0, 10, 10, 0]} barSize={25}>
                   <LabelList dataKey="porcentaje" position="right" formatter={(v) => `${v}%`} style={{ fontSize: 10, fontWeight: 'bold', fill: '#475569' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Historial de Ingresos</h3>
          </div>
          <div className="w-full h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={ingresosHistoricosProcesados} margin={{ top: 20, right: 15, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="mes" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 'bold', fill: '#94A3B8' }} />
                <YAxis hide />
                <Tooltip formatter={(value) => formatearDinero(value)} cursor={{ stroke: '#F8FAFC', strokeWidth: 2 }} contentStyle={{ borderRadius: '15px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }} />
                <Line type="monotone" dataKey="ingreso" stroke="#111A24" strokeWidth={4} dot={{ r: 4, fill: '#FF4C61', strokeWidth: 0 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10 mb-8">
        
        <div className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Ventas por Paquete</h3>
          </div>
          <div className="w-full h-[200px] md:h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={paquetesFiltrados} cx="50%" cy="50%" innerRadius="60%" outerRadius="80%" paddingAngle={6} dataKey="cantidad" nameKey="nombre" stroke="none">
                  {paquetesFiltrados.map((entry, i) => {
                    const esMensual = entry.nombre?.toLowerCase().includes('mensual');
                    return <Cell key={i} fill={esMensual ? '#111A24' : '#FF4C61'} />;
                  })}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '15px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px' }}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-2 bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Embudo de Conversión</h3>
          </div>
          <div className="w-full h-[200px] md:h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={embudoProcesado} margin={{ top: 10, right: 20, left: 20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorEmbudo" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#94A3B8" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#94A3B8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="estado" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 'bold', fill: '#94A3B8' }} />
                <YAxis hide />
                <Tooltip contentStyle={{ borderRadius: '15px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                <Area type="monotone" dataKey="cantidad" stroke="#475569" strokeWidth={3} fillOpacity={1} fill="url(#colorEmbudo)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-10 mb-8">
        
        <div className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Ingresos Generados por Maestro</h3>
             <FaChalkboardTeacher className="text-slate-200" />
          </div>
          <div className="w-full h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={maestrosProcesados} layout="vertical" margin={{ top: 0, right: 60, left: 30, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
                <XAxis type="number" hide />
                <YAxis dataKey="nombre" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 'bold', fill: '#475569' }} width={90} />
                <Tooltip formatter={(value) => formatearDinero(value)} cursor={{ fill: '#F8FAFC' }} contentStyle={{ borderRadius: '15px', border: 'none' }} />
                <Bar dataKey="ingresosGenerados" fill="#111A24" radius={[0, 10, 10, 0]} barSize={25}>
                   <LabelList dataKey="ingresosGenerados" position="right" formatter={(v) => formatearDinero(v)} style={{ fontSize: 10, fontWeight: 'bold', fill: '#475569' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Uso de Cupones de Promoción</h3>
             <FaTag className="text-slate-200" />
          </div>
          <div className="w-full h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={promocionesProcesadas} margin={{ top: 20, right: 0, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="titulo" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 'bold', fill: '#94A3B8' }} />
                <YAxis hide />
                <Tooltip cursor={{ fill: '#F8FAFC' }} contentStyle={{ borderRadius: '15px', border: 'none' }} />
                <Bar dataKey="usosActuales" fill="#FF4C61" radius={[10, 10, 0, 0]} maxBarSize={40}>
                   <LabelList dataKey="usosActuales" position="top" style={{ fontSize: 10, fontWeight: 'bold', fill: '#FF4C61' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
        
        <div className="lg:col-span-2 bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl border border-gray-50 flex flex-col items-center w-full">
          <div className="w-full flex justify-between items-center mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400">Asistencia por Horario</h3>
             <FaCalendarAlt className="text-slate-200" />
          </div>
          <div className="w-full h-[200px] md:h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={horariosProcesados} margin={{ top: 20, right: 0, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="horario" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 'bold', fill: '#94A3B8' }} />
                <YAxis hide />
                <Tooltip cursor={{ fill: '#F8FAFC' }} contentStyle={{ borderRadius: '15px', border: 'none' }} />
                <Bar dataKey="asistencias" fill="#94A3B8" radius={[10, 10, 0, 0]} maxBarSize={50}>
                   <LabelList dataKey="asistencias" position="top" style={{ fontSize: 10, fontWeight: 'bold', fill: '#475569' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 text-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] shadow-xl flex flex-col justify-between w-full">
          <div className="mb-6">
             <h3 className="text-[10px] md:text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Cuotas de Infraestructura</h3>
             <div className="flex items-center gap-2">
               <FaServer className="text-green-400" />
               <span className="text-sm font-bold text-green-400">Servicios Activos</span>
             </div>
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-xs font-bold uppercase tracking-widest mb-2">
                <span className="flex items-center gap-2 text-slate-400">
                  <FaEnvelope /> Brevo (Emails Diario)
                </span>
                <span>{data.graficas.medidorBrevo?.enviadosHoy || 0} / {data.graficas.medidorBrevo?.limiteDiario || 300}</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden relative">
                <div 
                  className={`h-full transition-all duration-1000 ${porcentajeBrevo > 85 ? 'bg-red-500' : 'bg-blue-500'}`} 
                  style={{ width: `${porcentajeBrevo}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold uppercase tracking-widest mb-2">
                <span className="flex items-center gap-2 text-slate-400">
                  <FaImage /> Cloudinary (Créditos)
                </span>
                <span>{data.graficas.medidorCloudinary?.usoCreditos || 0} / {data.graficas.medidorCloudinary?.limiteCreditos || 25}</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden relative">
                <div 
                  className={`h-full transition-all duration-1000 ${porcentajeCloudinary > 85 ? 'bg-red-500' : 'bg-[#FF4C61]'}`} 
                  style={{ width: `${porcentajeCloudinary}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};

export default DashboardAdmin;