import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { Link, useLocation } from 'react-router-dom';
import Swal from 'sweetalert2';
import api from '../services/api';

export const DashboardMaestro = () => {
  const { logout } = useAuth();
  const location = useLocation();
  const [clases, setClases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [claseExpandida, setClaseExpandida] = useState(null);

  const [modalGaleriaOpen, setModalGaleriaOpen] = useState(false);
  const [claseSeleccionada, setClaseSeleccionada] = useState(null);
  const [galeriaClase, setGaleriaClase] = useState([]);
  const [enlaceClase, setEnlaceClase] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const archivoClaseRef = useRef(null);

  useEffect(() => {
    fetchMisClases();
  }, []);

  const fetchMisClases = async () => {
    try {
      const { data } = await api.get('/maestros/mis-clases');
      setClases(data);
    } catch (error) {
      console.error("Error al cargar las clases", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleClase = (id) => {
    setClaseExpandida(claseExpandida === id ? null : id);
  };

  const abrirModalGaleria = (clase) => {
    setClaseSeleccionada(clase);
    setGaleriaClase(clase.galeria || []);
    setModalGaleriaOpen(true);
  };

  const cerrarModalGaleria = () => {
    setModalGaleriaOpen(false);
    setClaseSeleccionada(null);
    setGaleriaClase([]);
    setEnlaceClase('');
  };

  const handleSubirArchivoClase = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('archivo', file);

    Swal.fire({ title: 'Subiendo archivo...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
      const { data } = await api.post(`/multimedia/${claseSeleccionada.id}`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      setGaleriaClase([{ id: Date.now(), tipo: 'archivo', url: data.url }, ...galeriaClase]);
      Swal.close();
    } catch (error) {
      Swal.fire('Error', 'No se pudo subir a la galería de la clase.', 'error');
    }
  };

  const handleAgregarEnlaceClase = (e) => {
    e.preventDefault();
    if (enlaceClase.trim() === '') return;
    
    let tipo = 'enlace';
    if (enlaceClase.includes('youtube.com') || enlaceClase.includes('youtu.be')) tipo = 'youtube';
    if (enlaceClase.includes('instagram.com/reel')) tipo = 'reel';

    setGaleriaClase([{ id: Date.now(), tipo, url: enlaceClase }, ...galeriaClase]);
    setEnlaceClase('');
  };

  const eliminarDeGaleriaClase = (id) => {
    setGaleriaClase(galeriaClase.filter(item => item.id !== id));
  };

  const handleGuardarGaleriaClase = async () => {
    setIsSubmitting(true);
    try {
      const primeraFoto = galeriaClase.find(item => item.tipo === 'archivo' && item.url.match(/\.(jpeg|jpg|gif|png|webp)$/i));

      await api.put(`/maestros/clases/${claseSeleccionada.id}/galeria`, {
        galeria: galeriaClase,
        imagenPrincipal: primeraFoto ? primeraFoto.url : null
      });
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Galería de clase actualizada', showConfirmButton: false, timer: 3000 });
      fetchMisClases();
      cerrarModalGaleria();
    } catch (error) {
      Swal.fire({ title: 'Error', text: 'No se pudo guardar la galería.', icon: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const obtenerYoutubeEmbedUrl = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}`;
    }
    return url;
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans pb-20">
      
      <header className="bg-white border-b border-gray-200 px-8 py-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-10">
          <div>
            <h1 className="text-2xl font-serif font-bold text-slate-900">Portal Maestro</h1>
            <p className="text-gray-500 mt-1 text-xs tracking-widest uppercase font-semibold">Estilo Latino</p>
          </div>
          <nav className="hidden sm:flex gap-6 border-l border-gray-200 pl-8">
             <Link to="/maestro" className={`text-sm font-bold uppercase tracking-widest transition-colors ${location.pathname === '/maestro' ? 'text-slate-900 border-b-2 border-slate-900 pb-1' : 'text-slate-400 hover:text-slate-700'}`}>Mis Clases</Link>
             <Link to="/maestro/perfil" className={`text-sm font-bold uppercase tracking-widest transition-colors ${location.pathname === '/maestro/perfil' ? 'text-slate-900 border-b-2 border-slate-900 pb-1' : 'text-slate-400 hover:text-slate-700'}`}>Mi Perfil</Link>
          </nav>
        </div>
        <button onClick={logout} className="px-5 py-2 border border-slate-300 text-slate-700 text-xs font-bold uppercase tracking-widest hover:bg-slate-100 transition-colors rounded">
          Cerrar Sesión
        </button>
      </header>

      <main className="p-8 max-w-5xl mx-auto">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-800">Clases Asignadas</h2>
          <p className="text-sm text-gray-500 mt-1">Revisa tus horarios, alumnos y gestiona la galería de cada clase.</p>
        </div>

        {loading ? (
          <p className="text-center text-gray-500">Cargando tus clases...</p>
        ) : clases.length === 0 ? (
          <div className="bg-white p-10 rounded-xl border border-gray-200 shadow-sm text-center">
            <p className="text-gray-500 font-medium">Aún no tienes clases asignadas a tu cuenta.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {clases.map(clase => (
              <div key={clase.id} className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden transition-all">
                
                <div className="p-6 flex flex-col md:flex-row justify-between items-center gap-4">
                  <div className="flex-1 w-full cursor-pointer" onClick={() => toggleClase(clase.id)}>
                    <h3 className="text-xl font-bold text-slate-900">{clase.nombre}</h3>
                    <p className="text-sm text-gray-500 mt-1 uppercase tracking-wider font-medium">
                      {clase.horarios.length > 0 ? clase.horarios.map(h => `${h.dia} ${h.hora}`).join(' | ') : 'Sin horarios'}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-4 w-full md:w-auto">
                    <div className="text-center mr-4">
                      <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold mb-1">Ocupación</p>
                      <p className="text-lg font-bold text-slate-800">{clase.reservas.length} / <span className="text-gray-400">{clase.cupoTotal}</span></p>
                    </div>
                    <button onClick={() => abrirModalGaleria(clase)} className="px-4 py-2 bg-slate-900 text-white text-xs font-bold uppercase tracking-widest rounded shadow-md hover:bg-black">
                      Galería
                    </button>
                    <button onClick={() => toggleClase(clase.id)} className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-bold uppercase rounded border border-slate-300">
                      {claseExpandida === clase.id ? 'Ocultar Alumnos' : 'Ver Alumnos'}
                    </button>
                  </div>
                </div>

                {claseExpandida === clase.id && (
                  <div className="border-t border-gray-100 bg-slate-50 p-6">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Lista de Alumnos Inscritos</h4>
                    {clase.reservas.length === 0 ? (
                      <p className="text-sm text-gray-500 italic">No hay alumnos inscritos todavía.</p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {clase.reservas.map(res => (
                          <div key={res.id} className="bg-white p-4 rounded-lg border border-gray-200 flex justify-between items-center shadow-sm">
                            <div>
                              <p className="font-bold text-slate-800 text-sm">{res.nombreAlumno} {res.apellidos}</p>
                              <p className="text-xs text-gray-500 mt-1">{res.correo}</p>
                            </div>
                            <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider rounded ${res.estado === 'PAGADO' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                              {res.estado}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {modalGaleriaOpen && claseSeleccionada && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl w-full max-w-4xl shadow-2xl overflow-hidden relative max-h-[90vh] flex flex-col">
            <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 sticky top-0 z-10">
              <div>
                <h2 className="text-xl font-serif font-bold text-slate-900">Galería de Clase</h2>
                <p className="text-xs text-gray-500 uppercase tracking-widest mt-1">{claseSeleccionada.nombre}</p>
              </div>
              <button onClick={cerrarModalGaleria} className="text-gray-400 hover:text-red-500 font-bold text-xl">✕</button>
            </div>

            <div className="p-8 overflow-y-auto flex-1">
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <div className="flex-1 flex gap-2">
                  <input type="url" value={enlaceClase} onChange={(e) => setEnlaceClase(e.target.value)} placeholder="Pegar enlace de YouTube..." className="flex-1 px-4 py-2 rounded-lg border border-gray-300 text-sm focus:border-slate-900 focus:outline-none" />
                  <button onClick={handleAgregarEnlaceClase} className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-bold uppercase rounded border border-slate-300 hover:bg-slate-200">Añadir Link</button>
                </div>
                <div className="hidden sm:flex items-center text-gray-300">ó</div>
                <input type="file" accept="image/*,video/*" className="hidden" ref={archivoClaseRef} onChange={handleSubirArchivoClase} />
                <button onClick={() => archivoClaseRef.current.click()} className="px-6 py-2 bg-slate-900 text-white text-xs font-bold uppercase rounded hover:bg-black whitespace-nowrap">
                  Subir Archivo
                </button>
              </div>

              {galeriaClase.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 border border-dashed border-gray-300 rounded-lg">
                  <p className="text-sm text-gray-400 font-medium">No has agregado contenido a esta clase.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {galeriaClase.map((item, index) => {
                    const esPortada = item.tipo === 'archivo' && index === galeriaClase.findIndex(i => i.tipo === 'archivo' && i.url.match(/\.(jpeg|jpg|gif|png|webp)$/i));

                    return (
                      <div key={item.id} className={`relative aspect-square group rounded-lg overflow-hidden border bg-slate-100 ${esPortada ? 'border-blue-500 border-4' : 'border-gray-200'}`}>
                        {esPortada && (
                          <div className="absolute top-0 left-0 bg-blue-500 text-white text-[8px] font-bold px-2 py-1 z-20 rounded-br">PORTADA</div>
                        )}
                        {item.tipo === 'archivo' && item.url.match(/\.(jpeg|jpg|gif|png|webp)$/i) ? (
                          <img src={item.url} alt="Galeria" className="w-full h-full object-cover" />
                        ) : item.tipo === 'youtube' ? (
                          <iframe src={obtenerYoutubeEmbedUrl(item.url)} frameBorder="0" allowFullScreen className="w-full h-full pointer-events-none group-hover:opacity-50 transition-opacity"></iframe>
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center">
                            <span className="text-2xl mb-2">📱</span>
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest break-all line-clamp-2">{item.tipo}</span>
                          </div>
                        )}
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button onClick={() => eliminarDeGaleriaClase(item.id)} className="px-4 py-2 bg-red-500 text-white text-[10px] font-bold uppercase tracking-widest rounded hover:bg-red-600">Quitar</button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="px-8 py-6 border-t border-gray-100 flex justify-end gap-4 bg-white sticky bottom-0">
              <button onClick={cerrarModalGaleria} className="px-6 py-2 text-slate-500 text-xs font-bold uppercase hover:text-slate-900">Cancelar</button>
              <button onClick={handleGuardarGaleriaClase} disabled={isSubmitting} className="px-6 py-2 bg-slate-900 text-white text-xs font-bold uppercase rounded hover:bg-black shadow-md disabled:opacity-50">
                {isSubmitting ? 'Guardando...' : 'Guardar Galería'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};