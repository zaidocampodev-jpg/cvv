import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';

export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    const result = await login(email, password);

    if (!result.success) {
      setError(result.error);
    }
  };

  return (
    <div className="min-h-screen flex bg-white font-sans">
      <div className="hidden lg:flex lg:w-1/2 relative bg-slate-200">
        <img 
          src="https://images.unsplash.com/photo-1547153760-18fc86324498?q=80&w=1000&auto=format&fit=crop" 
          alt="Baile Latino Elegante" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-10 flex flex-col justify-end p-16 text-white w-full h-full bg-gradient-to-t from-black/80 to-transparent">
          <h2 className="text-5xl font-serif font-bold mb-2 italic">Estilo Latino</h2>
          <p className="text-lg text-gray-200 tracking-widest uppercase">Staff Portal</p>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-gray-50">
        <div className="w-full max-w-md bg-white p-12 rounded-lg shadow-sm border border-gray-100">
          <div className="mb-10 text-center lg:text-left">
            <h1 className="text-4xl font-serif font-bold text-slate-900 mb-3">Iniciar Sesión</h1>
            <p className="text-gray-500 font-light">Gestiona la academia desde un solo lugar.</p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">
                Email Corporativo
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-0 py-3 border-b-2 border-gray-200 bg-transparent focus:outline-none focus:border-slate-900 transition-colors"
                placeholder="ejemplo@estilolatino.com"
                required
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 mb-2">
                Contraseña
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-0 py-3 border-b-2 border-gray-200 bg-transparent focus:outline-none focus:border-slate-900 transition-colors"
                placeholder="••••••••"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-4 mt-8 rounded-none font-bold text-white bg-slate-900 hover:bg-black transition-all tracking-widest uppercase text-sm"
            >
              Entrar al sistema
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};