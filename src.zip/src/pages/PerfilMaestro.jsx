import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { Link, useLocation } from 'react-router-dom';
import Swal from 'sweetalert2';
import api from '../services/api';

export const PerfilMaestro = () => {
  const { logout } = useAuth();
  const location = useLocation();
  
  const fotoRef = useRef(null);
  const portadaRef = useRef(null);
  const galeriaRef = useRef(null);

  const [isLoading, setIsLoading] = useState(false);
  const [fotoPerfil, setFotoPerfil] = useState('');
  const [fotoPortada, setFotoPortada] = useState('');
  const [textos, setTextos] = useState({ biografia: '', filosofia: '', experiencia: '' });
  const [redes, setRedes] = useState([]); 
  const [galeria, setGaleria] = useState([]); 
  const [enlaceExterno, setEnlaceExterno] = useState('');

  const opcionesRedes = ['Instagram', 'TikTok', 'Facebook', 'X (Twitter)', 'YouTube'];

  useEffect(() => {
    cargarPerfil();
  }, []);

  const cargarPerfil = async () => {
    try {
      const { data } = await api.get('/maestros/mi-perfil');
      if (data) {
        setFotoPerfil(data.fotoPerfil || '');
        setFotoPortada(data.fotoPortada || '');
        setTextos({
          biografia: data.biografia || '',
          filosofia: data.filosofia || '',
          experiencia: data.experiencia || ''
        });
        setRedes(data.redesSociales || []);
        setGaleria(data.galeriaPersonal || []);
      }
    } catch (error) {
      console.error("Error al cargar perfil", error);
    }
  };

  const handleGuardarPerfil = async () => {
    setIsLoading(true);
    try {
      await api.put('/maestros/mi-perfil', {
        ...textos,
        redesSociales: redes,
        galeriaPersonal: galeria
      });
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Perfil guardado', showConfirmButton: false, timer: 3000 });
    } catch (error) {
      Swal.fire({ title: 'Error', text: 'No se pudo guardar el perfil.', icon: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubirFotoPerfil = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('archivo', file);
    Swal.fire({ title: 'Subiendo Perfil...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
      const { data } = await api.post('/maestros/mi-perfil/foto', formData, { headers: { 'Content-Type': 'multipart/form-data' }});
      setFotoPerfil(data.url);
      Swal.close();
    } catch (error) {
      Swal.fire('Error', 'No se pudo subir la foto.', 'error');
    }
  };

  const handleSubirFotoPortada = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('archivo', file);
    Swal.fire({ title: 'Subiendo Portada...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
      const { data } = await api.post('/maestros/mi-perfil/portada', formData, { headers: { 'Content-Type': 'multipart/form-data' }});
      setFotoPortada(data.url);
      Swal.close();
    } catch (error) {
      Swal.fire('Error', 'No se pudo subir la portada.', 'error');
    }
  };

  const handleSubirArchivoGaleria = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('archivo', file);
    Swal.fire({ title: 'Subiendo archivo...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
      const { data } = await api.post('/maestros/mi-perfil/galeria', formData, { headers: { 'Content-Type': 'multipart/form-data' }});
      setGaleria([{ id: Date.now(), tipo: 'archivo', url: data.url }, ...galeria]);
      Swal.close();
    } catch (error) {
      Swal.fire('Error', 'No se pudo subir a la galería.', 'error');
    }
  };

  const obtenerYoutubeEmbedUrl = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) return `https://www.youtube.com/embed/${match[2]}`;
    return url;
  };

  const handleAgregarEnlace = (e) => {
    e.preventDefault();
    if (enlaceExterno.trim() === '') return;
    let tipo = enlaceExterno.includes('youtube.com') || enlaceExterno.includes('youtu.be') ? 'youtube' : 
               enlaceExterno.includes('instagram.com/reel') ? 'reel' : 'enlace';
    setGaleria([{ id: Date.now(), tipo, url: enlaceExterno }, ...galeria]);
    setEnlaceExterno('');
  };

  const handleAddRed = () => {
    if (redes.length >= 3) return;
    setRedes([...redes, { plataforma: 'Instagram', url: '' }]);
  };

  const handleUpdateRed = (index, campo, valor) => {
    const nuevasRedes = [...redes];
    nuevasRedes[index][campo] = valor;
    setRedes(nuevasRedes);
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans pb-20">
      
      <header className="bg-white border-b border-gray-200 px-8 py-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-10">
          <div>
            <h1 className="text-2xl font-serif font-bold text-slate-900">Portal Maestro</h1>
            <p className="text-gray-500 mt-1 text-xs tracking-widest uppercase font-semibold">Estilo Latino</p>
          </div>
          <nav className="hidden sm:flex gap-6 border-l border-gray-200 pl-8">
             <Link to="/maestro" className={`text-sm font-bold uppercase tracking-widest transition-colors ${location.pathname === '/maestro' ? 'text-slate-900 border-b-2 border-slate-900 pb-1' : 'text-slate-400 hover:text-slate-700'}`}>Mis Clases</Link>
             <Link to="/maestro/perfil" className={`text-sm font-bold uppercase tracking-widest transition-colors ${location.pathname === '/maestro/perfil' ? 'text-slate-900 border-b-2 border-slate-900 pb-1' : 'text-slate-400 hover:text-slate-700'}`}>Mi Perfil</Link>
          </nav>
        </div>
        <div className="flex gap-3">
          <button onClick={logout} className="px-5 py-2 border border-slate-300 text-slate-700 text-xs font-bold uppercase tracking-widest hover:bg-slate-100 transition-colors rounded">
            Cerrar Sesión
          </button>
          <button onClick={handleGuardarPerfil} disabled={isLoading} className="px-6 py-2 bg-slate-900 text-white text-xs font-bold uppercase tracking-widest hover:bg-black transition-all rounded shadow-md">
            {isLoading ? 'Guardando...' : 'Guardar Perfil'}
          </button>
        </div>
      </header>

      <main className="p-8 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm text-center">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">Fotografía Oficial</h2>
            <div className="relative w-40 h-40 mx-auto mb-4 group cursor-pointer" onClick={() => fotoRef.current.click()}>
              <div className="w-full h-full rounded-full border-4 border-white shadow-lg overflow-hidden bg-slate-100 flex items-center justify-center">
                {fotoPerfil ? <img src={fotoPerfil} alt="Perfil" className="w-full h-full object-cover" /> : <span className="text-4xl text-slate-300">📸</span>}
              </div>
              <div className="absolute inset-0 bg-black/50 text-white text-[10px] font-bold uppercase flex items-center justify-center opacity-0 group-hover:opacity-100 rounded-full transition-all">Cambiar</div>
            </div>
            <input type="file" accept="image/*" className="hidden" ref={fotoRef} onChange={handleSubirFotoPerfil} />
            <p className="text-[11px] text-gray-400">Esta foto te representa en la academia.</p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm text-center">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Imagen de Portada (Fondo)</h2>
            <div className="relative w-full h-32 mx-auto mb-4 group cursor-pointer rounded-lg overflow-hidden border-2 border-dashed border-gray-300 hover:border-slate-400 transition-colors" onClick={() => portadaRef.current.click()}>
              {fotoPortada ? (
                <img src={fotoPortada} alt="Portada" className="w-full h-full object-cover" />
              ) : (
                <div className="flex flex-col items-center justify-center h-full bg-slate-50 text-slate-400 group-hover:bg-slate-100 transition-colors">
                  <span className="text-3xl mb-2">🖼️</span>
                  <span className="text-[10px] font-bold uppercase tracking-widest">Subir Fondo</span>
                </div>
              )}
              <div className="absolute inset-0 bg-black/60 text-white text-[10px] font-bold uppercase flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">Cambiar Portada</div>
            </div>
            <input type="file" accept="image/*" className="hidden" ref={portadaRef} onChange={handleSubirFotoPortada} />
            <p className="text-[11px] text-gray-400">Fondo oscuro de tu perfil público.</p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Mis Redes ({redes.length}/3)</h2>
              {redes.length < 3 && <button onClick={handleAddRed} className="text-xl font-bold text-slate-900 hover:text-slate-600">+</button>}
            </div>
            <div className="space-y-4">
              {redes.map((red, i) => (
                <div key={i} className="p-3 bg-gray-50 border border-gray-200 rounded relative group">
                  <button onClick={() => handleRemoveRed(i)} className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full text-[10px] opacity-0 group-hover:opacity-100">✕</button>
                  <select value={red.plataforma} onChange={(e) => handleUpdateRed(i, 'plataforma', e.target.value)} className="w-full mb-2 bg-white text-xs font-bold p-1 border-b uppercase tracking-wider">
                    {opcionesRedes.map(op => <option key={op} value={op}>{op}</option>)}
                  </select>
                  <input type="url" value={red.url} onChange={(e) => handleUpdateRed(i, 'url', e.target.value)} placeholder="https://..." className="w-full text-xs p-2 rounded border focus:border-slate-900 focus:outline-none" />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Biografía</label>
              <textarea value={textos.biografia} onChange={(e) => setTextos({...textos, biografia: e.target.value})} rows="4" className="w-full p-4 rounded-lg border text-sm focus:border-slate-900 focus:outline-none resize-none" placeholder="Cuéntale a los alumnos quién eres..."></textarea>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Filosofía de Clase</label>
                <textarea value={textos.filosofia} onChange={(e) => setTextos({...textos, filosofia: e.target.value})} rows="3" className="w-full p-4 rounded-lg border text-sm focus:border-slate-900 focus:outline-none resize-none" placeholder="Ej: Creo que el baile es sanar..."></textarea>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Logros / Experiencia</label>
                <textarea value={textos.experiencia} onChange={(e) => setTextos({...textos, experiencia: e.target.value})} rows="3" className="w-full p-4 rounded-lg border text-sm focus:border-slate-900 focus:outline-none resize-none" placeholder="Ej: Campeón Nacional 2024..."></textarea>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-6">Portafolio Multimedia</h2>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <div className="flex-1 flex gap-2">
                <input type="url" value={enlaceExterno} onChange={(e) => setEnlaceExterno(e.target.value)} placeholder="Pegar enlace de YouTube..." className="flex-1 px-4 py-2 rounded-lg border text-sm focus:border-slate-900 focus:outline-none" />
                <button onClick={handleAgregarEnlace} className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-bold uppercase rounded border hover:bg-slate-200">Añadir Link</button>
              </div>
              <div className="hidden sm:flex items-center text-gray-300">ó</div>
              <input type="file" accept="image/*,video/*" className="hidden" ref={galeriaRef} onChange={handleSubirArchivoGaleria} />
              <button onClick={() => galeriaRef.current.click()} className="px-6 py-2 bg-slate-900 text-white text-xs font-bold uppercase rounded hover:bg-black whitespace-nowrap">
                Subir Archivo
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {galeria.map((item) => (
                <div key={item.id} className="relative aspect-square group rounded-lg overflow-hidden border bg-slate-100">
                  {item.tipo === 'archivo' && item.url.match(/\.(jpeg|jpg|gif|png|webp)$/i) ? (
                    <img src={item.url} alt="Galeria" className="w-full h-full object-cover" />
                  ) : item.tipo === 'youtube' ? (
                    <iframe src={obtenerYoutubeEmbedUrl(item.url)} frameBorder="0" allowFullScreen className="w-full h-full pointer-events-none group-hover:opacity-50"></iframe>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center">
                      <span className="text-2xl mb-2">📱</span>
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest break-all line-clamp-2">{item.tipo}</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button onClick={() => setGaleria(galeria.filter(g => g.id !== item.id))} className="px-4 py-2 bg-red-500 text-white text-[10px] font-bold uppercase rounded">Quitar</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};